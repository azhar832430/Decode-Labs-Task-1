"""
Simple Rule-Based Chatbot
Author: Student Project
Description:
This chatbot responds to predefined user inputs using if-else logic.
It handles greetings, basic questions, and exit commands.
"""


def chatbot_response(user_input):
    """
    This function takes user input and returns a predefined chatbot response.
    """
    user_input = user_input.lower().strip()

    if user_input == "hello" or user_input == "hi" or user_input == "hey":
        return "Hello! How can I help you?"

    elif user_input == "assalamualaikum" or user_input == "salam":
        return "Walaikum Assalam! How are you?"

    elif user_input == "how are you":
        return "I am fine, thank you! What about you?"

    elif user_input == "what is your name":
        return "My name is SimpleBot."

    elif user_input == "who created you":
        return "I was created as a beginner Python chatbot project."

    elif user_input == "what can you do":
        return "I can reply to simple predefined questions using rule-based logic."

    elif user_input == "help":
        return "You can ask me: hello, how are you, what is your name, what can you do, or type bye to exit."

    elif user_input == "bye" or user_input == "exit" or user_input == "quit" or user_input == "goodbye":
        return "Goodbye! Have a nice day."

    else:
        return "Sorry, I do not understand that. Please type 'help' to see what you can ask."


def main():
    """
    Main function to run the chatbot continuously until the user exits.
    """
    print("====================================")
    print("       Simple Rule-Based Chatbot     ")
    print("====================================")
    print("Bot: Hello! I am SimpleBot.")
    print("Bot: Type 'help' to see commands or type 'bye' to exit.")

    while True:
        user_input = input("You: ")
        response = chatbot_response(user_input)
        print("Bot:", response)

        if user_input.lower().strip() in ["bye", "exit", "quit", "goodbye"]:
            break


if __name__ == "__main__":
    main()
