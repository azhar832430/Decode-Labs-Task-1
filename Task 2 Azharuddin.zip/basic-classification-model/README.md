# Basic Classification Model

A beginner-friendly machine learning project that builds a basic classification model using a small dataset.

## Project Goal

Build a simple classification model using the Iris dataset.

The project covers:

- Loading and understanding a dataset
- Splitting data into training and testing sets
- Applying a simple classification algorithm
- Evaluating model accuracy

## Key Skills

- Data handling
- Supervised learning basics
- Model training
- Model testing
- Accuracy evaluation

## Dataset Used

This project uses the built-in **Iris dataset** from Scikit-learn.

The dataset contains flower measurements and classifies flowers into three types:

1. Setosa
2. Versicolor
3. Virginica

Features used:

- Sepal length
- Sepal width
- Petal length
- Petal width

## Algorithm Used

This project uses the **K-Nearest Neighbors (KNN)** classification algorithm.

KNN predicts the class of a new data point by checking the nearest existing data points.

## Folder Structure

```text
basic-classification-model/
│
├── src/
│   └── classification_model.py
│
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## How to Run This Project

### 1. Clone the repository

```bash
git clone https://github.com/your-username/basic-classification-model.git
cd basic-classification-model
```

### 2. Install required libraries

```bash
pip install -r requirements.txt
```

### 3. Run the project

```bash
python src/classification_model.py
```

## Expected Output

You will see:

- Dataset information
- Training and testing data size
- Model accuracy
- Classification report
- Sample prediction result

Example:

```text
Model Accuracy: 1.00

Sample Prediction:
Input: [[5.1, 3.5, 1.4, 0.2]]
Predicted Class: Setosa
```

## What I Learned

Through this project, I learned:

- How to load a dataset
- How to separate input features and target labels
- How to split data into training and testing sets
- How to train a classification model
- How to test model performance
- How to make predictions using a trained model

## GitHub Upload Steps

### Step 1: Create a new repository on GitHub

Repository name:

```text
basic-classification-model
```

### Step 2: Open terminal inside the project folder

Run these commands:

```bash
git init
git add .
git commit -m "Initial commit - basic classification model"
git branch -M main
git remote add origin https://github.com/your-username/basic-classification-model.git
git push -u origin main
```

## Author

Created as a beginner Machine Learning classification project.
