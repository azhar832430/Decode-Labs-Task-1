"""
Basic Classification Model Project

Goal:
Create a simple classification model using a small dataset.

Dataset:
Iris dataset from Scikit-learn.

Algorithm:
K-Nearest Neighbors Classifier.
"""

import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report


def load_dataset():
    """Load and return the Iris dataset as a pandas DataFrame."""
    iris = load_iris()

    # Convert dataset into a DataFrame for better understanding
    data = pd.DataFrame(iris.data, columns=iris.feature_names)
    data["target"] = iris.target
    data["target_name"] = data["target"].apply(lambda x: iris.target_names[x])

    return data, iris


def understand_dataset(data):
    """Display basic information about the dataset."""
    print("========== Dataset Preview ==========")
    print(data.head())

    print("\n========== Dataset Shape ==========")
    print("Rows and Columns:", data.shape)

    print("\n========== Dataset Information ==========")
    print(data.info())

    print("\n========== Target Classes ==========")
    print(data["target_name"].value_counts())


def train_model(iris):
    """Split the dataset, train the model, and return results."""
    # Features/input data
    X = iris.data

    # Target/output labels
    y = iris.target

    # Split data into training and testing sets
    # 80% training data, 20% testing data
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    print("\n========== Data Splitting ==========")
    print("Training data size:", X_train.shape)
    print("Testing data size:", X_test.shape)

    # Create KNN classification model
    model = KNeighborsClassifier(n_neighbors=3)

    # Train the model
    model.fit(X_train, y_train)

    # Make predictions
    y_pred = model.predict(X_test)

    return model, X_test, y_test, y_pred


def evaluate_model(y_test, y_pred, iris):
    """Evaluate the trained model."""
    accuracy = accuracy_score(y_test, y_pred)

    print("\n========== Model Evaluation ==========")
    print("Model Accuracy:", accuracy)

    print("\n========== Classification Report ==========")
    print(classification_report(y_test, y_pred, target_names=iris.target_names))


def sample_prediction(model, iris):
    """Make a sample prediction using the trained model."""
    # Sample flower measurement:
    # [sepal length, sepal width, petal length, petal width]
    sample_data = [[5.1, 3.5, 1.4, 0.2]]

    prediction = model.predict(sample_data)
    predicted_class = iris.target_names[prediction[0]]

    print("\n========== Sample Prediction ==========")
    print("Input:", sample_data)
    print("Predicted Class:", predicted_class.capitalize())


def main():
    """Main function to run the complete project."""
    data, iris = load_dataset()

    understand_dataset(data)

    model, X_test, y_test, y_pred = train_model(iris)

    evaluate_model(y_test, y_pred, iris)

    sample_prediction(model, iris)


if __name__ == "__main__":
    main()
